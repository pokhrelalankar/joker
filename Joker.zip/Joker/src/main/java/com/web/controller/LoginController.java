package com.web.controller;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class LoginController {
	
	@PostMapping("/auth")
	public String login(HttpServletRequest request) {
		String username=request.getParameter("username");
		String password=request.getParameter("password");
		if("jack".equals(username) && "jill".equals(password)){
			request.setAttribute("message","Hey! you are my friend!!");
		}else{
			request.setAttribute("message","Hey! you are not my friend!!");
		}
		return "login";
	}

}
